import aiogram.utils.markdown as md
from aiogram import Bot, Dispatcher, types
import asyncio
from aiogram import Bot, Dispatcher, executor
import csv, datetime
import sqlite3

API_TOKEN = '1988101693:AAFjlJgbQGCN5MCYhaErYLbjkeuDzNJ4uyA'

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands='start')
async def cmd_start(message: types.Message):
    await message.reply("Привет!")
    statistics(message.chat.id, message.text)
    stat(message.chat.id, message.text)

def statistics(user_id, command):
    data = datetime.datetime.today().strftime("%d-%m-%Y %H:%M")
    with open('data.csv', 'a', newline="") as fil:
        wr = csv.writer(fil, delimiter=';')
        wr.writerow([data, user_id, command])

def stat(user_id, command):
    conn = sqlite3.connect('TelegramBot.db')
    cur = conn.cursor()
    data = datetime.datetime.today().strftime("%d-%m-%Y %H:%M")
    print(cur.execute("INSERT INTO statistice(User_id, User_command, date) VALUES('%s', '%s', '%s')" % (user_id, command, data)))
    conn.commit()
    cur.close()

if __name__ == '__main__':
    executor.start_polling(dp)
